from flask import Flask, render_template, request, redirect, url_for, flash
import os
import cv2
import numpy as np
from PIL import Image
import io
import base64
import torch

app = Flask(__name__)
app.secret_key = "femur_fracture_detection_secret_key"
app.config['UPLOAD_FOLDER'] = 'static/uploads/'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max upload

# Create upload folder if it doesn't exist
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# YOLO model path
YOLO_MODEL_PATH = r"best.pt"

# Load the YOLO model (loaded only once when app starts)
def load_model():
    try:
        model = torch.hub.load('best.pt', 'custom', path=YOLO_MODEL_PATH)
        return model
    except Exception as e:
        print(f"Error loading model: {e}")
        return None

# Try to load the model at startup
yolo_model = load_model()

def detect_fracture(image_path):
    """
    Detect femur fractures in the image using YOLO model
    Returns: bounding boxes and classifications
    """
    global yolo_model
    
    # If model failed to load earlier, try again
    if yolo_model is None:
        yolo_model = load_model()
        if yolo_model is None:
            # Fallback to mock detection if model can't be loaded
            return mock_detection(image_path)
    
    try:
        # Make prediction
        results = yolo_model(image_path)
        
        # Extract detection results
        detections = []
        
        # Convert results to pandas dataframe
        df = results.pandas().xyxy[0]
        
        # Extract bounding boxes, classes and confidences
        for _, row in df.iterrows():
            x_min, y_min, x_max, y_max = int(row['xmin']), int(row['ymin']), int(row['xmax']), int(row['ymax'])
            class_name = row['name'] if 'name' in row else f"Class {int(row['class'])}"
            confidence = float(row['confidence'])
            
            detections.append({
                'bbox': [x_min, y_min, x_max, y_max],
                'class': class_name,
                'confidence': confidence
            })
        
        return detections
    
    except Exception as e:
        print(f"Error during detection: {e}")
        # Fallback to mock detection if real detection fails
        return mock_detection(image_path)

def mock_detection(image_path):
    """
    Mock detection function as fallback
    """
    # Read image
    img = cv2.imread(image_path)
    height, width = img.shape[:2]
    
    # Mock detection results
    detections = [{
        'bbox': [int(width * 0.3), int(height * 0.4), 
                 int(width * 0.7), int(height * 0.6)],
        'class': "Femur Fracture",
        'confidence': 0.92
    }]
    
    return detections

def draw_detection(image_path, detections):
    """
    Draw bounding boxes on the image and add labels
    Returns: base64 encoded image
    """
    # Read the image
    img = cv2.imread(image_path)
    
    # Colors for different classes (BGR format)
    colors = [
        (0, 255, 0),    # Green
        (0, 0, 255),    # Red
        (255, 0, 0),    # Blue
        (0, 255, 255),  # Yellow
        (255, 0, 255)   # Magenta
    ]
    
    # Draw bounding boxes and labels
    for i, det in enumerate(detections):
        x_min, y_min, x_max, y_max = det['bbox']
        class_name = det['class']
        confidence = det['confidence']
        
        # Get color
        color = colors[i % len(colors)]
        
        # Draw rectangle
        cv2.rectangle(img, (x_min, y_min), (x_max, y_max), color, 2)
        
        # Prepare label text
        label = f"{class_name}: {confidence:.2f}"
        
        # Get text size
        (text_width, text_height), baseline = cv2.getTextSize(
            label, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 1)
        
        # Draw filled rectangle for label background
        cv2.rectangle(img, (x_min, y_min - text_height - 10),
                     (x_min + text_width, y_min), color, -1)
        
        # Put text
        cv2.putText(img, label, (x_min, y_min - 5),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
    
    # Convert to base64 for HTML display
    _, buffer = cv2.imencode('.png', img)
    img_str = base64.b64encode(buffer).decode('utf-8')
    
    return f"data:image/png;base64,{img_str}"

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        # Check if the post request has the file part
        if 'file' not in request.files:
            flash('No file part')
            return redirect(request.url)
        
        file = request.files['file']
        
        # If user does not select file, browser also
        # submit an empty part without filename
        if file.filename == '':
            flash('No selected file')
            return redirect(request.url)
        
        # Check if the file is an allowed image type
        allowed_extensions = {'png', 'jpg', 'jpeg'}
        if '.' not in file.filename or \
           file.filename.rsplit('.', 1)[1].lower() not in allowed_extensions:
            flash('File type not allowed')
            return redirect(request.url)
        
        # Save the file
        filename = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
        file.save(filename)
        
        # Detect fractures
        detections = detect_fracture(filename)
        
        # Draw bounding boxes
        result_image = draw_detection(filename, detections)
        
        return render_template('result.html', 
                              result_image=result_image,
                              detections=detections)
    
    return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True)